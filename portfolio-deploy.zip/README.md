# Khurshid Shaik — Portfolio

## Deploy to GitHub Pages (5 minutes)
1. Create a repo named exactly: **KhurshidShaik.github.io** (public)
2. Upload everything in this folder: index.html, avatar-girl.svg
3. Also add (from your computer):
   - Khurshid_Shaik_resume.pdf  → makes the "Résumé" nav button work
4. Settings → Pages → Branch: main, folder: / (root) → Save
5. Live in ~2 min at: https://khurshidshaik.github.io

## Before going live — one edit left
- In index.html, search for "your-linkedin" and replace with your real LinkedIn URL.

## After you build each project
- Point each "view code →" link at its specific repo
- Change "status: to build" to "status: live"

# Khurshid Shaik — Portfolio

Everything is now in ONE file: index.html (avatar is embedded — no separate image needed).

## Deploy to GitHub Pages
1. Create a public repo named exactly: KhurshidShaik.github.io
2. Upload: index.html + Khurshid_Shaik_resume.pdf (for the Résumé button)
3. Settings -> Pages -> Branch: main, / (root) -> Save
4. Live at https://khurshidshaik.github.io in ~2 min

## After building each project
- Point each "view code" link at its repo; change "status: to build" to "status: live"
